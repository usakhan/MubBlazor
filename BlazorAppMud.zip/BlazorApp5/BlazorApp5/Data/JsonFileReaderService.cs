﻿using System.Text.Json;
namespace BlazorApp5.Data
{
    public class JsonFileReaderService
    {

        public Task<List<ReaderObject>> ReadJson(DateTime startDate)
        {
            List<ReaderObject> readerObjects = new List<ReaderObject>();
            string jsonString = File.ReadAllText(@"D:\BlazorApp5\BlazorApp5\data.json");

            // Deserialize the JSON string into a C# object
            readerObjects = JsonSerializer.Deserialize<List<ReaderObject>>(jsonString);

            return Task.FromResult(readerObjects);

            //return readerObjects;
        }
    }
    public class ReaderObject
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
