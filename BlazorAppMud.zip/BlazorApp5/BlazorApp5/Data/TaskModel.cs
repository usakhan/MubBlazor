﻿namespace BlazorApp5.Data
{
    public class TaskModel
    {
        public string Task { get; set; }
        public bool IsComplete { get; set; }
    }
}
