
namespace BlazorApp5.Data
{
    public class WeatherForecastService
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        public Task<WeatherForecast[]> GetForecastAsync(DateTime startDate)
        {
            return Task.FromResult(Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = startDate.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            }).ToArray());
        }
        //public Task<List<ReaderObject>> ReadJsonFile(DateTime startDate)
        //{
        //    List<ReaderObject> readerObjects = new List<ReaderObject>();
        //    string jsonString = File.ReadAllText(@"D:\BlazorApp5\BlazorApp5\data.json");

        //    // Deserialize the JSON string into a C# object
        //    readerObjects = JsonSerializer.Deserialize<List<ReaderObject>>(jsonString);

        //    return Task.FromResult(readerObjects);

        //    //return readerObjects;
        //}

        
    }
    //public class ReaderObject
    //{
    //    public string Name { get; set; }
    //    public int Age { get; set; }
    //}
}